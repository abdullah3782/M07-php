<!-- //crido de manera general tot el que necessitaré cridar Abdullah Waris Butt -->

<?php

use persist\JugadorDAO;

require_once "controller/ControllerInterface.php";
require_once "view/JugadorView.class.php";
require_once "model/Jugador/persist/JugadorDAO.class.php";
require_once "model/Jugador/Jugador.class.php";
require_once "util/Jugador/JugadorValidation/JugadorMessage.class.php";
require_once "util/Jugador/JugadorValidation/JugadorFormValidation.class.php";
require_once "util/Jugador/functions_extra/funcions_archivos.php";

class JugadorController
{

    //atributs que segur que tindran tots els controladors
    private $view;
    private $model;

    private $view2;

    //constructor del controlador. Instancia objectes de les classes de la vista i el model necessàries per poder 
    //comunicar aquest controlador amb la resta

    public function __construct()
    {

        // càrrega de la vista
        $this->view = new JugadorView();

        $this->view2 = new EntrenadorView();

        // càrrega del model de dades
        $this->model = new JugadorDAO();
    }

    // aquest mètode el tenen tots els nostres controladors
    // serveix per saber en quin lloc del menú estem

    public function processRequest()
    {

        //inicialitzem 3 variables que necessitarem
        $request = NULL; //aquest NULL serveix per al cas que sigui la primera vegada que hi entrem, sinó valdrà $_POST["action"] o $_GET["option"]
        $_SESSION['info'] = array(); //per donar sortida a tots els missatges generals d'informació
        $_SESSION['error'] = array(); ////per donar sortida a tots els missatges d'error

        // recupera l'acció SI VENIM DES D'UN FORMULARI --> PER POST, o bé
        // recupera l'opció SI VENIM D'UNA OPCIÓ DEL MENÚ--> PER GET
        //només hi pot haver una d'aquestes dues situacions,


        $request = isset($_POST["action"]) ? $_POST["action"] : NULL;
        if (isset($_POST["action"])) {
            $request = $_POST["action"];
        } else if (isset($_GET["option"])) {
            $request = $_GET["option"];
        }


        //mirem totes les opcions d'action o d'option ASSIGNADES a la variable $request
        switch ($request) {


            case "ejer1": //opció de menu que trobem a MainMenu.html, menú de la vista que carreguem el primer cop amb el display
                $this->ejer1();
                break;

            case "ejer2": //opció de formulari
                $this->ejer2();
                break;

            case "ejer3": //opció de formulari
                $this->ejer3();
                break;

            case "ejer4": //opció de formulari
                $this->ejer4();
                break;

            case "formAdd": //OpcionMenu: formulario de AÑADIR categoria
                $this->formAdd();

                break;
            case "formDelete":
               $this->mostrarID();
               break;
            case "add": //Opción del formulario CategoryFormAdd <input type="submit" name="action" value="add" />
                $this->add();
                break;
            case "borrar": //Opción del formulario CategoryFormAdd <input type="submit" name="action" value="add" />
                $this->delete();
                break;
            default: //en el cas que vinguem per primer cop a categories o no haguem escollit res de res, $request=NULL;
                $this->view->display(); //mètode de la classe JugadorView.class.php
        }
    }


    /**
     * Displays the home page with a menu containing 4 options: Ejercicio1, Ejercicio2, Ejercicio3, and Ejercicio4.
     * The body of the home page welcomes the selection and presents the entire team of players (20 icons/photos).
     * @return void
     */
    public function mostrarID()
    {

        $this->view2->displayLoggedIn("view/options/BuscarJugadorByID/BuscarJugadorByID.php");
    }


    /**
     * Displays the home page with a menu containing 4 options: Ejercicio1, Ejercicio2, Ejercicio3, and Ejercicio4.
     * The body of the home page welcomes the selection and presents the entire team of players (20 icons/photos).
     * @return void
     */
    public function delete()
    {
        $jugadorValid = JugadorFormValidation::checkData(JugadorFormValidation::DELETE_FIELDS);

        if (empty($_SESSION['error'])) {
            $jugador = $this->model->searchById($jugadorValid->getId());

            if (($jugador)) {
                $result = $this->model->delete($jugadorValid->getId());

                if ($result == TRUE) {
                    $_SESSION['info'] = JugadorMessage::INF_FORM['delete'];
                    $jugadorValid = NULL;
                } else {
                    $_SESSION['error'] = JugadorMessage::ERR_DAO['delete'];
                }
            } else {
                $_SESSION['error'] = JugadorMessage::ERR_FORM['not_exists_id'];
            }
        }

        $this->view2->displayLoggedIn("view/options/BuscarJugadorByID/BuscarJugadorByID.php", $jugadorValid);
    }

    /**
     * Displays the home page with a menu containing 4 options: Ejercicio1, Ejercicio2, Ejercicio3, and Ejercicio4.
     * The body of the home page welcomes the selection and presents the entire team of players (20 icons/photos).
     * @return void
     */
    public function home()
    {

        //necessitem cridar al model
        $mensaje = $this->model->home();

        if (!empty($mensaje)) { // array void or array of Jugador objects?
            $_SESSION['info'] = JugadorMessage::INF_FORM['found'];
        } else {
            $_SESSION['error'] = JugadorMessage::ERR_FORM['not_found'];
        }

        $this->view->display("view/options/JugadorHome/JugadorHome.php", $mensaje);
    }




    /**
     * Activity 1: Generates a letter for each player and saves the files on disk.
     * Players are defined in a file, and the generated files will be named, for example, ferranTorres.txt, gavi.txt.
     * @return void
     */
    public function ejer1()
    {


        $mensaje = $this->model->ejer1_arrayNombres();

        $directory = "./util/Jugador/dataCreatedWithTemplate/";

        $written = writeInFileTxt($mensaje, $directory);


        if ($written) {
            $_SESSION['info'] = JugadorMessage::INF_FORM['written'];
        } else {
            $_SESSION['error'] = JugadorMessage::ERR_FORM['not_written'];
        }

        $this->view->display("view/options/JugadorEj1/JugadorEj1.php",); //li passem la variable que es diu $template a la vista JugadorView.class.php

    }


    /**
     * This function is part of Activity 2. It retrieves an array of names from the model,
     * formats them into card-like structures, and displays them using HTML <pre> tags.
     * @return void
     */
    public function ejer2()
    {

        $mensaje = $this->model->ejer1_arrayNombres();

        $text = createCardFormat($mensaje);

        if ($mensaje) {
            $_SESSION['info'] = JugadorMessage::INF_FORM['found'];
            $this->view->display("view/options/JugadorEj2/JugadorEj2.php", $text); //li passem la variable que es diu $template a la vista JugadorView.class.php

        } else {
            $_SESSION['error'] = JugadorMessage::ERR_FORM['not_found'];
        }
    }


    /**
     * Activity 3: Similar to exercise 2, but the letter template is in a file that the program reads.
     * The file is named index.view.html, and it contains HTML with the text of the letter.
     *
     * @return void
     */
    public function ejer3()
    {
        $mensaje = $this->model->ejer1_arrayNombres();

        $location = "./util/Jugador/templateToRead/index.view.html";


        $text = make_letters_file_html($location, $mensaje);

        if ($mensaje) {
            $_SESSION['info'] = JugadorMessage::INF_FORM['found'];
            $this->view->display("view/options/JugadorEj2/JugadorEj2.php", $text); //li passem la variable que es diu $template a la vista JugadorView.class.php

        } else {
            $_SESSION['error'] = JugadorMessage::ERR_FORM['not_found'];
        }
    }


    /**
     * Activity 4: Based on exercise 3, generate letters and save them to disk in HTML files (e.g., ferranTorres.html, gavi.html).
     * Also, create a file 'index.html' with a list of links to the generated letter files.
     *
     * @return void
     */
    public function ejer4()
    {

        $mensaje = $this->model->ejer1_arrayNombres();

        $location = "./util/Jugador/templateToRead/index.view.html";

        $text = make_letters_file_html($location, $mensaje);

        $directoryToWrite = "./util/Jugador/dataCreatedWithTemplate/html/";

        $written = writeInFilehtml($mensaje, $directoryToWrite);

        if ($written) {
            $_SESSION['info'] = JugadorMessage::INF_FORM['found'];
            $this->view->display("view/options/JugadorEj4/JugadorEj4.php", $mensaje); //li passem la variable que es diu $template a la vista JugadorView.class.php

        } else {
            $_SESSION['error'] = JugadorMessage::ERR_FORM['not_found'];
        }
    }

    /**
     * Aquest mètode carga el formulario de insertar/añadir categoria
     * @param none
     * @return none
     **/
    public function formAdd()
    {
        $this->view2->displayLoggedIn("view/form/JugadorForm/JugadorFormAdd.php");
    }

    /**
     * Ejecuta la acción de insertar categoria
     * @param none
     * @return none
     **/
    public function add()
    {
        $jugadorValid = JugadorFormValidation::checkData(JugadorFormValidation::ADD_FIELDS); //const ADD_FIELDS = array('id','name');

        if (empty($_SESSION['error'])) {
            //busco que no haya una categoria con este id que quieren añadir
            $category = $this->model->searchById($jugadorValid->getId());

            //si lo hemos encontrado o no
            if (is_null($category)) {
                //añadir la nueva categoria
                $result = $this->model->add($jugadorValid);

                if ($result == TRUE) {
                    $_SESSION['info'] = JugadorMessage::INF_FORM['insert'];
                    //$categoryValid=NULL;
                } else {
                    $_SESSION['error'] = JugadorMessage::ERR_DAO['insert'];
                }
            } else { //el id existe
                $_SESSION['error'] = JugadorMessage::ERR_FORM['exists_id'];
            }
        }

        $this->view2->displayLoggedIn("view/options/JugadorHome/JugadorHome.php", $jugadorValid);
    }
}
