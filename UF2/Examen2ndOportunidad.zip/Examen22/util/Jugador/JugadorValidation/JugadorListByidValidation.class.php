<?php

class JugadorListByidValidation
{

    const ADD_FIELDS = array('id', 'name', 'pais', 'dorsal','edad', 'role', 'goal', 'partidos' );
    const MODIFY_FIELDS = array('id', 'name');
    const DELETE_FIELDS = array('id');
    const SEARCH_FIELDS = array('id');

    const NUMERIC = "/[^0-9]/";
    const ALPHABETIC = "/[^a-z A-Z]/";

    public static function checkData($fields)
    {
        $id = NULL;
        $name = NULL;

        foreach ($fields as $field) {
            switch ($field) {
                case 'id':
                    // filter_var retorna los datos filtrados o FALSE si el filtro falla
                    $id = trim(filter_input(INPUT_POST, 'id'));
                    $idValid = !preg_match(self::NUMERIC, $id);
                    if (empty($id)) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['empty_id']);
                    } else if ($idValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_id']);
                    }
                    break;
                case 'name':
                    $name = trim(filter_input(INPUT_POST, 'name'));
                    $nameValid = !preg_match(self::ALPHABETIC, $name);
                    if (empty($name)) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['empty_name']);
                    } else if ($nameValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_name']);
                    }
                    break;
                case 'pais':
                    // filter_var retorna los datos filtrados o FALSE si el filtro falla
                    $pais = trim(filter_input(INPUT_POST, 'pais'));
                    $paisValid = filter_var($pais, FILTER_SANITIZE_STRING);
                    if ($paisValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_pais']);
                    }
                    break;
                case 'dorsal':
                    $dorsal = trim(filter_input(INPUT_POST, 'dorsal'));
                    $dorsalValid = filter_var($dorsal, FILTER_SANITIZE_NUMBER_INT);
                    if ($dorsalValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_dorsal']);
                    }
                    break;
                case 'edad':
                    $edad = trim(filter_input(INPUT_POST, 'edad'));
                    $edadValid = filter_var($edad, FILTER_SANITIZE_STRING);
                    if ($edadValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_edad']);
                    }
                    break;
                case 'role':
                    $role = trim(filter_input(INPUT_POST, 'role'));
                    $roleValid = filter_var($role, FILTER_SANITIZE_STRING);
                    if ($roleValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_role']);
                    }
                    break;
                case 'goal':
                    $goal = trim(filter_input(INPUT_POST, 'goal'));
                    $goalValid = filter_var($goal, FILTER_SANITIZE_NUMBER_INT);
                    if ($goalValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_goal']);
                    }
                    break;
                case 'partidos':
                    $partidos = trim(filter_input(INPUT_POST, 'partidos'));
                    $partidosValid = filter_var($partidos, FILTER_SANITIZE_NUMBER_INT);
                    if ($partidosValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_partidos']);
                    }
                    break;
            }
        }

        $jugador = new Jugador($id);

        return $jugador;
    }
}
