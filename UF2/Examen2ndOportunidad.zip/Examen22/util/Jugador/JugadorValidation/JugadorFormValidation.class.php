<?php
//crido de manera general tot el que necessitaré cridar Abdullah Waris Butt

class JugadorFormValidation
{

    const ADD_FIELDS = array('id', 'name', 'descripcion', 'author','edad' );
    const MODIFY_FIELDS = array('id', 'name');
    const DELETE_FIELDS = array('id');
    const SEARCH_FIELDS = array('id');

    const NUMERIC = "/[^0-9]/";
    const ALPHABETIC = "/[^a-z A-Z]/";

    public static function checkData($fields)
    {
        $id = NULL;
        $name = NULL;
        $descripcion = NULL;
        $author = NULL;
        $edad  = NULL;
     ;

        foreach ($fields as $field) {
            switch ($field) {
                case 'id':
                    // filter_var retorna los datos filtrados o FALSE si el filtro falla
                    $id = trim(filter_input(INPUT_POST, 'id'));
                    $idValid = !preg_match(self::NUMERIC, $id);
                    if (empty($id)) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['empty_id']);
                    } else if ($idValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_id']);
                    }
                    break;
                case 'name':
                    $name = trim(filter_input(INPUT_POST, 'name'));
                    $nameValid = !preg_match(self::ALPHABETIC, $name);
                    if (empty($name)) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['empty_name']);
                    } else if ($nameValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_name']);
                    }
                    break;
                case 'descripcion':
                    // filter_var retorna los datos filtrados o FALSE si el filtro falla
                    $descripcion = trim(filter_input(INPUT_POST, 'descripcion'));
                    $descripcionValid = filter_var($descripcion, FILTER_SANITIZE_STRING);
                    if ($descripcionValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_pais']);
                    }
                    break;
                case 'author':
                    $author = trim(filter_input(INPUT_POST, 'author'));
                    $authorValid = filter_var($author, FILTER_SANITIZE_STRING);
                    if ($authorValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_dorsal']);
                    }
                    break;
                case 'edad':
                    $edad = trim(filter_input(INPUT_POST, 'edad'));
                    $edadValid = filter_var($edad, FILTER_SANITIZE_NUMBER_INT);
                    if ($edadValid == FALSE) {
                        array_push($_SESSION['error'], JugadorMessage::ERR_FORM['invalid_edad']);
                    }
                    break;
            
            }
        }

        $jugador = new Jugador($id, $name, $descripcion, $author, $edad);

        return $jugador;
    }
}
