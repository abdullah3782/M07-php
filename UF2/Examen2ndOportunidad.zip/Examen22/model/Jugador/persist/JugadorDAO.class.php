<?php
// Abdullah Waris Butt

namespace persist;

use identificador;
use Jugador;
use JugadorMessage;
use vector;

require_once "model/Jugador/Jugador.class.php";
require_once "model/DBConnect.class.php";
require_once "model/ModelInterface.php";


//class to handle a jugador
class JugadorDAO
{

    //propietat que tenen tots els DAO per connectar-se a l'arxiu i poder fer les accions bàsiques generals
    private $dbConnect;

    public function __construct()
    {
        $this->dbConnect = new \DBConnect("util/Entrenador/csvJugadores/jugadores.csv");
    }



    /**
     * Retrieves information about the team of players from the data source.
     * @return array An array of Jugador objects representing each player in the team.
     */
    public function home()
    {
        $response = array();
        $linesToFile = array();
        $linesToFile = $this->dbConnect->realAllLines();
        if (count($linesToFile) > 0) {
            foreach ($linesToFile as $line) {
                if (!empty($line)) {
                    $pieces = explode(";", $line);
                    $jugador = new Jugador(
                        $pieces[0] ?? null,
                        $pieces[1] ?? null,
                        $pieces[2] ?? null,
                        $pieces[3] ?? null,
                        $pieces[4] ?? null
                    );
                $response[] = $jugador;
                }
            }
        }
        return $response;
    }





    /**
     * Retrieves an array of player names from the data source.
     * @return array An array of player names.
     */
    public function ejer1_arrayNombres()
    {
        $jugadorName = [];
        $linesToFile = array();
        $linesToFile = $this->dbConnect->realAllLines();
        if (count($linesToFile) > 0) {
            foreach ($linesToFile as $line) {
                if (!empty($line)) {
                    $pieces = explode(";", $line);
                    $jugadorName[] = $pieces[1];
                }
            }
        }


        return $jugadorName;
    }

    /**
     * Selecionar una categoria per id
     * @param $id identificador de la categoria a buscar
     * @return Juagdor objecte encontrado or NULL(no existe el id)
     */
    public function searchById($id)
    {
        $linesToFile = $this->dbConnect->realAllLines();
        foreach ($linesToFile as $line) {
            if (!empty($line)) {
                $pieces = explode(";", $line);
                //creo una categoria con el id y el nombre que lo he cogido en pieces.
                $juagdor = new Jugador(
                    isset($pieces[0]) ? $pieces[0] : null,
                    isset($pieces[1]) ? $pieces[1] : null,
                    isset($pieces[2]) ? $pieces[2] : null,
                    isset($pieces[3]) ? $pieces[3] : null,
                    isset($pieces[4]) ? $pieces[4] : null
                );
                if ($pieces[0] == $id) { //si el valor de la categoria de la posicion 
                    return $juagdor;
                }
            }
        }
        return NULL;
    }


    /**
     * Afegeix una categoria
     * @param Jugador objecte
     * @return TRUE O FALSE
     */
    public function add($jugador)
    {

        $result = $this->dbConnect->addNewLine($jugador->writingNewLine());

        if ($result == FALSE) {
            $_SESSION['error'] = JugadorMessage::ERR_DAO['insert'];
        }

        return $result;
    }


    public function delete($id)
    {
        $linesToFile = array();
        $linesToFile = $this->dbConnect->realAllLines();
        if (count($linesToFile) > 0) {
            foreach ($linesToFile as $indice => $line) {
                if (!empty($line)) {
                    $pieces = explode(';', $line);
                    if ($pieces[0] == $id) {
                        array_splice($linesToFile, $indice, 1);
                    }
                }
            }
        }
        return $this->dbConnect->writeToFile($linesToFile);
    }
}
