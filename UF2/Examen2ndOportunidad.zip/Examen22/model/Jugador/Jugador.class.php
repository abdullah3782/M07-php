<?php
//crido de manera general tot el que necessitaré cridar Abdullah Waris Butt

class Jugador {
    
    private $id;
    private $nombre;
    private $descripcion;
    private $author;
    private $fNacimiento;
   

    /**
     * @param $id
     * @param $nombre
     * @param $descripcion
     * @param $author
     * @param $fNacimiento
     */
    public function __construct($id = NULL, $nombre = NULL, $descripcion = NULL, $author = NULL, $fNacimiento = NULL)
    {
        $this->id = $id;
        $this->nombre = $nombre;
        $this->descripcion = $descripcion;
        $this->author = $author;
        $this->fNacimiento = $fNacimiento;
       
    }

    /**
     * @return mixed|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed|null $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

    /**
     * @return mixed|null
     */
    public function getNombre()
    {
        return $this->nombre;
    }

    /**
     * @param mixed|null $nombre
     */
    public function setNombre($nombre): void
    {
        $this->nombre = $nombre;
    }

    /**
     * @return mixed|null
     */
    public function getDescripcion()
    {
        return $this->descripcion;
    }

    /**
     * @param mixed|null $descripcion
     */
    public function setDescripcion($descripcion): void
    {
        $this->descripcion = $descripcion;
    }

    /**
     * @return mixed|null
     */
    public function getAuthor()
    {
        return $this->author;
    }

    /**
     * @param mixed|null $author
     */
    public function setAuthor ($author): void
    {
        $this->author = $author;
    }

    /**
     * @return mixed|null
     */
    public function getFNacimiento()
    {
        return $this->fNacimiento;
    }

    /**
     * @param mixed|null $fNacimiento
     */
    public function setFNacimiento($fNacimiento): void
    {
        $this->fNacimiento = $fNacimiento;
    }

   
    public function writingNewLine()
    { //__toString()
        return "\n$this->id;$this->nombre;$this->descripcion;$this->author;$this->fNacimiento;"; // podríem volem algun mètode extrar de la classe que ens fos interessant i general
    }

}
