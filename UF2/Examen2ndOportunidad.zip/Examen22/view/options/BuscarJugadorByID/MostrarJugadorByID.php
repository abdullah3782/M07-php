<div id="content">
        <?php
        if (isset($content)) {

                $content->getId();
                echo '<div style="width: 16.66%; margin: 10px; text-align: center; background-color: white; padding: 10px; border-radius: 8px;">';
                echo "<img src='http://127.0.0.1/m07-php/UF2/mvc1-juego-Jugadores/view/options/JugadorHome/img/{$content->getFoto()}' width='150px' height=''>";
                echo "<div>";
                echo "<span>Id: {$content->getId()}</span> <br>";
                echo "<span>Nombre: {$content->getNombre()}</span> <br>";
                echo "<span>País: {$content->getPais()}</span> <br>";
                echo "<span>Dorsal: {$content->getNumCamiseta()}</span> <br>";
                echo "<span>Edad: {$content->calculate_age()}</span> <br>";
                echo "<span>Role: {$content->getRolJugador()}</span> <br>";
                echo "<span>Goals: {$content->getNumGoles()}</span> <br>";
                echo "<span>Partidos: {$content->getNumPartidos()}</span> <br>";
                echo "</div>";
                echo '</div>';
            }
        
        ?>
</div>