<!-- //crido de manera general tot el que necessitaré cridar Abdullah Waris Butt -->

<div id="content">
    <form method="post" action="">
        <fieldset>
            <legend>Add jugador</legend>
            
            <div>
                <label>Id *:</label>
                <input type="number" placeholder="Id" name="id" value="<?php if (isset($content)) { echo $content->getId(); } ?>" />
            </div>

            <div>
                <label>Titulo *:</label>
                <input type="text" placeholder="Name" name="name" value="<?php if (isset($content)) { echo $content->getName(); } ?>" />
            </div>

            <div>
                <label>Descripcion:</label>
                <input type="text" placeholder="Pais" name="descripcion" value="<?php if (isset($content)) { echo $content->getDescripcion(); } ?>" />
            </div>

            <div>
                <label>Author *:</label>
                <input type="text" placeholder="Dorsal" name="author" value="<?php if (isset($content)) { echo $content->getAuthor(); } ?>" />
            </div>

            <div>
                <label>Fecha de nacimiento (NO PONGAS TEXTO)*:</label>
                <input type="text" placeholder="Fecha de nacimiento (NO PONGAS TEXTO)*" name="edad" value="<?php if (isset($content)) { echo $content->getEdad(); } ?>" />
            </div>



            <div>
                <label>* Required fields</label>
                <input type="submit" name="action" value="add" />
                <input type="submit" name="reset" value="reset" />
            </div>
            
        </fieldset>
    </form>
</div>
